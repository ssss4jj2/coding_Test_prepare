# 시간과 메모리 측정

import time

start_time = time.time()

# program 진행

end_time = time.time()
print("time : ", end_time - start_time) # 수행 시간 출력